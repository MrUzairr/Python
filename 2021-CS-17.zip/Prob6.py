# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
# Sixth Task

# Extracting function from func.py file
from funcs import *

# Taking Input
a = input("Enter a No.: ")
   
# Given Output
print("Iterative Method:",SumIterative(a))
print("Recursive Method:",SumRecursive(int(a)))
