# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
# Fifth Task

# Extracting function from func.py file
from funcs import *
    

string = "University of Engineering and Technology Lahore"

# Taking Input
starting = input("Enter Starting index: ")
ending = input("Enter Ending index: ")

# Given Output
print("Output: ",StringReverse(string,starting,ending))